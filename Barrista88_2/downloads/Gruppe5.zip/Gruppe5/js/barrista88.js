
            const displayElement = document.getElementById("anzeige");
            const powerButton = document.getElementById("power");

            let power = false;

            function StatusAnAus(){
                if(power){
                    displayElement.innerText = "Die Maschine ist an.";
                }
                else{
                    displayElement.innerText = "Die Maschine ist aus."
                }
            }

            
                powerButton.addEventListener("click", function (){
                    power = !power;
                    StatusAnAus();
                }) 

                StatusAnAus();

